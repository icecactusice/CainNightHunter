@echo off
set GRADLE_VERSION=8.8
set DIST=%USERPROFILE%\.gradle\wrapper\dists\gradle-%GRADLE_VERSION%-bin\manual
set GRADLE=%DIST%\gradle-%GRADLE_VERSION%\bin\gradle.bat
if not exist "%GRADLE%" (
  if not exist "%DIST%" mkdir "%DIST%"
  powershell -Command "Invoke-WebRequest https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip -OutFile '%DIST%\gradle.zip'" || exit /b 1
  powershell -Command "Expand-Archive -Force '%DIST%\gradle.zip' '%DIST%'" || exit /b 1
)
call "%GRADLE%" -p "%~dp0" %*
