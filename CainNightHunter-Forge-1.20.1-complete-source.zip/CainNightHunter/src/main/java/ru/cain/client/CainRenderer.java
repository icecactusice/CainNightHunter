package ru.cain.client;

import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import ru.cain.CainMod;
import ru.cain.entity.CainEntity;

public class CainRenderer extends MobRenderer<CainEntity, CainModel> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(CainMod.MODID, "textures/entity/cain.png");
    public CainRenderer(EntityRendererProvider.Context context) {
        super(context, new CainModel(context.bakeLayer(CainModel.LAYER)), 0.65F);
        addLayer(new CainEyesLayer(this));
    }
    @Override public ResourceLocation getTextureLocation(CainEntity entity) { return TEXTURE; }
}
