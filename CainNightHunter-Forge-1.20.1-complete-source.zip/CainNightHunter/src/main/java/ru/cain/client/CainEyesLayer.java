package ru.cain.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.MultiBufferSource;
import ru.cain.entity.CainEntity;
import net.minecraft.resources.ResourceLocation;
import ru.cain.CainMod;

public class CainEyesLayer extends RenderLayer<CainEntity, CainModel> {
    private static final RenderType EYES = RenderType.eyes(new ResourceLocation(CainMod.MODID, "textures/entity/cain_eyes.png"));
    public CainEyesLayer(RenderLayerParent<CainEntity, CainModel> parent) { super(parent); }
    @Override public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight,
                                 CainEntity entity, float limbSwing, float limbSwingAmount,
                                 float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
        getParentModel().renderEyes(poseStack, buffer.getBuffer(EYES), 0xF000F0, 0);
    }
}
