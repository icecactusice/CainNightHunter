package ru.cain.client;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import ru.cain.CainMod;
import ru.cain.entity.CainEntity;

public class CainModel extends EntityModel<CainEntity> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(new ResourceLocation(CainMod.MODID, "cain"), "main");
    public static final ModelLayerLocation EYES_LAYER = new ModelLayerLocation(new ResourceLocation(CainMod.MODID, "cain"), "eyes");
    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart eyes;

    public CainModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.eyes = root.getChild("eyes");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-5.5F, -34F, -3.5F, 11F, 22F, 7F, new CubeDeformation(0.0F))
                .texOffs(0, 26).addBox(-6.5F, -35F, -3.8F, 13F, 4F, 8F), PartPose.ZERO);
        root.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(0, 40).addBox(-5F, -44F, -4F, 10F, 10F, 8F)
                .texOffs(36, 0).addBox(-7F, -42F, -1F, 2F, 5F, 2F)
                .texOffs(36, 0).addBox(5F, -42F, -1F, 2F, 5F, 2F), PartPose.ZERO);
        root.addOrReplaceChild("left_arm", CubeListBuilder.create().texOffs(36, 12)
                .addBox(-8F, -31F, -2F, 3F, 19F, 4F), PartPose.ZERO);
        root.addOrReplaceChild("right_arm", CubeListBuilder.create().texOffs(36, 12)
                .addBox(5F, -31F, -2F, 3F, 19F, 4F), PartPose.ZERO);
        root.addOrReplaceChild("left_leg", CubeListBuilder.create().texOffs(50, 0)
                .addBox(-5F, -12F, -2F, 4F, 12F, 4F), PartPose.ZERO);
        root.addOrReplaceChild("right_leg", CubeListBuilder.create().texOffs(50, 0)
                .addBox(1F, -12F, -2F, 4F, 12F, 4F), PartPose.ZERO);
        root.addOrReplaceChild("eyes", CubeListBuilder.create()
                .texOffs(20, 19).addBox(-3.2F, -40.5F, -4.35F, 1.7F, 1.3F, 0.5F)
                .texOffs(36, 19).addBox(1.5F, -40.5F, -4.35F, 1.7F, 1.3F, 0.5F), PartPose.ZERO);
        return LayerDefinition.create(mesh, 64, 64);
    }

    public static LayerDefinition createEyesLayer() { return createBodyLayer(); }

    @Override public void setupAnim(CainEntity entity, float limbSwing, float limbSwingAmount,
                                    float ageInTicks, float netHeadYaw, float headPitch) {
        head.yRot = netHeadYaw * ((float)Math.PI / 180F) * 0.35F;
        head.xRot = headPitch * ((float)Math.PI / 180F) * 0.35F + (float)Math.sin(ageInTicks * 0.08F) * 0.035F;
        eyes.yRot = head.yRot;
        eyes.xRot = head.xRot;
    }

    @Override public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight,
                                         int packedOverlay, float red, float green, float blue, float alpha) {
        root.getChild("torso").render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        head.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        root.getChild("left_arm").render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        root.getChild("right_arm").render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        root.getChild("left_leg").render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        root.getChild("right_leg").render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }

    public void renderEyes(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay) {
        eyes.render(poseStack, buffer, packedLight, packedOverlay, 1F, 1F, 1F, 1F);
    }
}
