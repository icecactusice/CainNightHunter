package ru.cain.registry;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import ru.cain.CainMod;
import ru.cain.entity.CainEntity;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, CainMod.MODID);

    public static final RegistryObject<EntityType<CainEntity>> CAIN = ENTITIES.register("cain",
            () -> EntityType.Builder.of(CainEntity::new, MobCategory.MONSTER)
                    .sized(1.15F, 3.0F).clientTrackingRange(12).updateInterval(2).build("cain"));
}
