package ru.cain.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import ru.cain.logic.NightmareManager;

public class CainEntity extends PathfinderMob {
    private int stareTicks;
    private int breakCooldown;
    private boolean hunting;
    private boolean executionMode;

    public CainEntity(EntityType<? extends PathfinderMob> type, net.minecraft.world.level.Level level) {
        super(type, level);
        setNoGravity(true);
        xpReward = 0;
        setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 50.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.78D)
                .add(Attributes.FLYING_SPEED, 1.15D)
                .add(Attributes.ATTACK_DAMAGE, 12.0D)
                .add(Attributes.FOLLOW_RANGE, 96.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D);
    }

    @Override protected void registerGoals() {
        goalSelector.addGoal(1, new LookAtPlayerGoal(this, Player.class, 64.0F));
        goalSelector.addGoal(2, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    public void beginExecution(ServerPlayer player) {
        executionMode = true;
        setNoPhysics(true);
        hunting = true;
        setTarget(player);
    }

    @Override public void tick() {
        super.tick();
        if (level().isClientSide) return;

        if (level().dimension() == net.minecraft.world.level.Level.OVERWORLD && level().isDay()) {
            discard();
            return;
        }

        Player target = getTarget() instanceof Player p && p.isAlive() ? p : null;
        if (!hunting) {
            stareTicks++;
            if (target != null) getLookControl().setLookAt(target, 30.0F, 30.0F);
            if (stareTicks >= 300) hunting = true;
        }

        if (hunting && target != null) {
            Vec3 aim = target.position().add(0, target.getBbHeight() * 0.55D, 0).subtract(position());
            double speed = executionMode ? 0.34D : 0.48D;
            Vec3 desired = aim.normalize().scale(speed);
            setDeltaMovement(getDeltaMovement().scale(0.72D).add(desired.scale(0.28D)));
            getLookControl().setLookAt(target, 45.0F, 45.0F);
            if (distanceToSqr(target) < 3.0D) {
                if (executionMode && target instanceof ServerPlayer serverPlayer) {
                    serverPlayer.kill();
                    discard();
                    return;
                }
                if (target instanceof ServerPlayer serverPlayer && level() instanceof ServerLevel serverLevel
                        && level().dimension() == net.minecraft.world.level.Level.OVERWORLD) {
                    NightmareManager.beginCapture(serverLevel, serverPlayer, this);
                }
            }
            if (!executionMode) breakNearbyStone();
        } else {
            setDeltaMovement(Vec3.ZERO);
        }

        if (breakCooldown > 0) breakCooldown--;
        if (tickCount % 8 == 0 && random.nextFloat() < 0.65F) {
            ((ServerLevel) level()).sendParticles(net.minecraft.core.particles.ParticleTypes.SMOKE,
                    getX(), getY() + 1.6D, getZ(), 2, 0.28D, 0.45D, 0.28D, 0.005D);
        }
    }

    private void breakNearbyStone() {
        if (breakCooldown > 0) return;
        breakCooldown = 10;
        BlockPos center = blockPosition();
        for (BlockPos pos : BlockPos.betweenClosed(center.offset(-1, -1, -1), center.offset(1, 2, 1))) {
            BlockState state = level().getBlockState(pos);
            if (isBreakableStone(state)) {
                level().destroyBlock(pos, false, this);
                break;
            }
        }
    }

    private boolean isBreakableStone(BlockState state) {
        return state.is(Blocks.STONE) || state.is(Blocks.COBBLESTONE) ||
                state.is(Blocks.MOSSY_COBBLESTONE) || state.is(Blocks.DEEPSLATE) ||
                state.is(Blocks.COBBLED_DEEPSLATE) || state.is(Blocks.POLISHED_DEEPSLATE) ||
                state.is(Blocks.DEEPSLATE_BRICKS) || state.is(Blocks.DEEPSLATE_TILES) ||
                state.is(Blocks.ANDESITE) || state.is(Blocks.POLISHED_ANDESITE) ||
                state.is(Blocks.DIORITE) || state.is(Blocks.POLISHED_DIORITE) ||
                state.is(Blocks.GRANITE) || state.is(Blocks.POLISHED_GRANITE) ||
                state.is(Blocks.TUFF) || state.is(Blocks.BLACKSTONE) ||
                state.is(Blocks.POLISHED_BLACKSTONE) || state.is(Blocks.BASALT) ||
                state.is(Blocks.SMOOTH_BASALT) || state.is(Blocks.STONE_BRICKS) ||
                state.is(Blocks.MOSSY_STONE_BRICKS) || state.is(Blocks.CRACKED_STONE_BRICKS) ||
                state.is(Blocks.BRICKS);
    }

    @Override public boolean causeFallDamage(float distance, float multiplier,
            net.minecraft.world.damagesource.DamageSource source) { return false; }
}
