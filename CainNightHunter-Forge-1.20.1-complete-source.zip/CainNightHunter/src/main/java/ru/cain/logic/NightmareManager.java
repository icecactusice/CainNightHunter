package ru.cain.logic;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.block.state.properties.DoorHingeSide;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import ru.cain.CainMod;
import ru.cain.entity.CainEntity;
import ru.cain.registry.ModEntities;

import java.util.*;

@Mod.EventBusSubscriber(modid = CainMod.MODID)
public final class NightmareManager {
    public static final ResourceKey<Level> NIGHTMARE = ResourceKey.create(Registries.DIMENSION,
            new ResourceLocation(CainMod.MODID, "nightmare"));
    private static long lastNightId = Long.MIN_VALUE;
    private static final String CAPTURED = "cain_captured";
    private static final String TIMER = "cain_timer";
    private static final String PHASE = "cain_capture_phase";

    private NightmareManager() {}

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.level instanceof ServerLevel level)
                || level != level.getServer().overworld()) return;
        MinecraftServer server = level.getServer();
        long nightId = Math.floorDiv(level.getDayTime(), 24000L);
        if (level.isNight() && lastNightId != nightId) {
            lastNightId = nightId;
            if (level.getEntities(ModEntities.CAIN.get(), e -> e.isAlive()).isEmpty()) {
                List<ServerPlayer> candidates = server.getPlayerList().getPlayers().stream()
                        .filter(p -> p.level() == level && p.isAlive() && !p.isSpectator()).toList();
                if (!candidates.isEmpty()) {
                    ServerPlayer chosen = candidates.get(level.random.nextInt(candidates.size()));
                    double angle = level.random.nextDouble() * Math.PI * 2.0D;
                    int dx = (int) Math.round(Math.cos(angle) * 5.0D);
                    int dz = (int) Math.round(Math.sin(angle) * 5.0D);
                    BlockPos spawn = level.getHeightmapPos(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING,
                            chosen.blockPosition().offset(dx, 0, dz));
                    CainEntity cain = ModEntities.CAIN.get().create(level);
                    if (cain != null) {
                        cain.moveTo(spawn.getX() + 0.5D, spawn.getY(), spawn.getZ() + 0.5D,
                                chosen.getYRot() + 180.0F, 0.0F);
                        cain.setTarget(chosen);
                        level.addFreshEntity(cain);
                    }
                }
            }
        }
        if (!level.isNight()) {
            level.getEntities(ModEntities.CAIN.get(), CainEntity::isAlive).forEach(CainEntity::discard);
        }
    }

    public static void beginCapture(ServerLevel overworld, ServerPlayer player, CainEntity cain) {
        if (player.getPersistentData().getBoolean(CAPTURED)) return;
        ServerLevel pocket = overworld.getServer().getLevel(NIGHTMARE);
        if (pocket == null) {
            player.hurt(overworld.damageSources().magic(), 8.0F);
            return;
        }
        var data = player.getPersistentData();
        data.putBoolean(CAPTURED, true);
        data.putInt(PHASE, 30); // 1.5-second pull-in animation window
        data.putInt(TIMER, 1200);
        data.putDouble("cain_return_x", player.getX());
        data.putDouble("cain_return_y", player.getY());
        data.putDouble("cain_return_z", player.getZ());
        data.putFloat("cain_return_yaw", player.getYRot());
        data.putFloat("cain_return_pitch", player.getXRot());
        data.putLong("cain_maze_seed", player.getUUID().getMostSignificantBits() ^ player.getUUID().getLeastSignificantBits());
        data.putDouble("cain_pull_x", cain.getX());
        data.putDouble("cain_pull_y", cain.getY() + 1.0D);
        data.putDouble("cain_pull_z", cain.getZ());
        player.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                net.minecraft.world.effect.MobEffects.BLINDNESS, 45, 0, false, false));
        player.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN, 35, 5, false, false));
        cain.setTarget(null);
        cain.setDeltaMovement(0, 0, 0);
        cain.discard();
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer player)) return;
        var data = player.getPersistentData();
        if (!data.getBoolean(CAPTURED)) return;
        if (data.getInt(PHASE) > 0) {
            int phase = data.getInt(PHASE) - 1;
            data.putInt(PHASE, phase);
            ServerLevel current = player.serverLevel();
            double progress = (30.0D - phase) / 30.0D;
            double pullX = player.getPersistentData().getDouble("cain_return_x") +
                    (player.getPersistentData().getDouble("cain_pull_x") - player.getPersistentData().getDouble("cain_return_x")) * progress;
            double pullY = player.getPersistentData().getDouble("cain_return_y") +
                    (player.getPersistentData().getDouble("cain_pull_y") - player.getPersistentData().getDouble("cain_return_y")) * progress;
            double pullZ = player.getPersistentData().getDouble("cain_return_z") +
                    (player.getPersistentData().getDouble("cain_pull_z") - player.getPersistentData().getDouble("cain_return_z")) * progress;
            player.teleportTo(current, pullX, pullY, pullZ, Set.of(), player.getYRot(), player.getXRot());
            current.sendParticles(net.minecraft.core.particles.ParticleTypes.PORTAL,
                    player.getX(), player.getY() + 1.0D, player.getZ(), 18,
                    0.45D, 0.8D, 0.45D, 0.15D);
            if (phase == 0) enterMaze(player);
            return;
        }
        if (!player.level().dimension().equals(NIGHTMARE)) return;
        int left = data.getInt(TIMER) - 1;
        data.putInt(TIMER, left);
        player.displayClientMessage(Component.literal("§4КЕЙН §8| §cДо его появления: §f" + Math.max(0, (left + 19) / 20) + " сек."), true);
        if (left <= 0) {
            data.putInt(TIMER, -1);
            spawnExecutioner(player);
        } else if (left == 200) {
            player.displayClientMessage(Component.literal("§4Стены начинают двигаться..."), false);
        }
        if (data.getInt("cain_execution_timer") > 0) {
            int remaining = data.getInt("cain_execution_timer") - 1;
            data.putInt("cain_execution_timer", remaining);
            if (remaining <= 0 && player.isAlive()) player.kill();
        }
    }

    private static void enterMaze(ServerPlayer player) {
        ServerLevel pocket = player.getServer().getLevel(NIGHTMARE);
        if (pocket == null) { player.getPersistentData().putBoolean(CAPTURED, false); return; }
        long seed = player.getPersistentData().getLong("cain_maze_seed");
        int baseX = Math.floorMod((int) (seed ^ (seed >>> 32)), 100000) * 64;
        int baseZ = Math.floorMod((int) (seed >>> 17), 100000) * 64;
        buildMaze(pocket, baseX, baseZ, seed);
        player.getPersistentData().putInt("cain_maze_x", baseX);
        player.getPersistentData().putInt("cain_maze_z", baseZ);
        player.teleportTo(pocket, baseX + 1.5D, 1.0D, baseZ + 1.5D, Set.of(), player.getYRot(), player.getXRot());
    }

    /** Creates an individual 31x31 DFS maze for each player, in a separate region of the pocket dimension. */
    private static void buildMaze(ServerLevel level, int baseX, int baseZ, long seed) {
        boolean[][] wall = new boolean[31][31];
        for (boolean[] row : wall) Arrays.fill(row, true);
        Random random = new Random(seed);
        ArrayList<int[]> stack = new ArrayList<>();
        wall[1][1] = false;
        stack.add(new int[]{1, 1});
        int[][] directions = {{0,-2},{2,0},{0,2},{-2,0}};
        while (!stack.isEmpty()) {
            int[] cell = stack.get(stack.size() - 1);
            ArrayList<int[]> options = new ArrayList<>();
            for (int[] d : directions) {
                int nx = cell[0] + d[0], nz = cell[1] + d[1];
                if (nx > 0 && nx < 30 && nz > 0 && nz < 30 && wall[nx][nz]) options.add(d);
            }
            if (options.isEmpty()) { stack.remove(stack.size() - 1); continue; }
            int[] d = options.get(random.nextInt(options.size()));
            int nx = cell[0] + d[0], nz = cell[1] + d[1];
            wall[cell[0] + d[0] / 2][cell[1] + d[1] / 2] = false;
            wall[nx][nz] = false;
            stack.add(new int[]{nx, nz});
        }
        // Guaranteed exit path and a door in the outer wall.
        wall[29][29] = false;
        wall[30][29] = false;
        for (int cx = -1; cx <= 31; cx++) for (int cz = -1; cz <= 31; cz++) {
            BlockPos floor = new BlockPos(baseX + cx, 0, baseZ + cz);
            level.getChunkAt(floor);
            level.setBlock(floor, Blocks.DEEPSLATE_BRICKS.defaultBlockState(), 3);
            for (int y = 1; y <= 4; y++) {
                BlockPos p = new BlockPos(baseX + cx, y, baseZ + cz);
                boolean isDoorGap = cx == 31 && cz == 29;
                boolean isWall = !isDoorGap && (cx < 0 || cz < 0 || cx > 30 || cz > 30 || (cx >= 0 && cx <= 30 && cz >= 0 && cz <= 30 && wall[cx][cz]));
                level.setBlock(p, isWall ? Blocks.DEEPSLATE_BRICKS.defaultBlockState() : Blocks.AIR.defaultBlockState(), 3);
            }
            level.setBlock(new BlockPos(baseX + cx, 5, baseZ + cz), Blocks.POLISHED_BLACKSTONE.defaultBlockState(), 3);
        }
        // Clear the spawn chamber and the door approach.
        for (int x=0;x<=2;x++) for(int z=0;z<=2;z++)
            for(int y=1;y<=4;y++) level.setBlock(new BlockPos(baseX+x,y,baseZ+z), Blocks.AIR.defaultBlockState(),3);
        BlockPos lower = new BlockPos(baseX + 31, 1, baseZ + 29);
        var door = Blocks.IRON_DOOR.defaultBlockState()
                .setValue(DoorBlock.FACING, Direction.SOUTH)
                .setValue(DoorBlock.HALF, DoubleBlockHalf.LOWER)
                .setValue(DoorBlock.HINGE, DoorHingeSide.LEFT)
                .setValue(DoorBlock.OPEN, false);
        level.setBlock(lower, door, 3);
        level.setBlock(lower.above(), door.setValue(DoorBlock.HALF, DoubleBlockHalf.UPPER), 3);
        level.setBlock(new BlockPos(baseX + 1, 1, baseZ + 1), Blocks.SOUL_LANTERN.defaultBlockState(), 3);
    }

    private static void spawnExecutioner(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        int x = player.getPersistentData().getInt("cain_maze_x");
        int z = player.getPersistentData().getInt("cain_maze_z");
        CainEntity executioner = ModEntities.CAIN.get().create(level);
        if (executioner != null) {
            executioner.moveTo(x + 30.5D, 1.0D, z + 29.5D, 180.0F, 0.0F);
            level.addFreshEntity(executioner);
            executioner.beginExecution(player);
        }
        player.getPersistentData().putInt("cain_execution_timer", 100);
        player.displayClientMessage(Component.literal("§4КЕЙН §8| §cОн вышел из стены. БЕГИ!"), false);
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        event.getEntity().getPersistentData().putBoolean(CAPTURED, false);
        event.getEntity().getPersistentData().putInt(TIMER, 0);
        event.getEntity().getPersistentData().putInt("cain_execution_timer", 0);
    }

    @SubscribeEvent
    public static void onMazeDoor(PlayerInteractEvent.RightClickBlock event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || !player.level().dimension().equals(NIGHTMARE)) return;
        if (!event.getLevel().getBlockState(event.getPos()).is(Blocks.IRON_DOOR)) return;
        if (!player.getPersistentData().getBoolean(CAPTURED)) return;
        ServerLevel overworld = player.getServer().overworld();
        var data = player.getPersistentData();
        data.putBoolean(CAPTURED, false);
        data.putInt(TIMER, 0);
        data.putInt("cain_execution_timer", 0);
        player.teleportTo(overworld, data.getDouble("cain_return_x"), data.getDouble("cain_return_y"),
                data.getDouble("cain_return_z"), Set.of(), data.getFloat("cain_return_yaw"), data.getFloat("cain_return_pitch"));
        event.setCanceled(true);
    }
}
